import "./App.scss";
import React from "react";
import Home from "./components/Home";
import Layout from "../src/components/Layout";
import "bootstrap/dist/css/bootstrap.min.css";
import "primeflex/primeflex.css";
import "primereact/resources/themes/saga-blue/theme.css";
import "primereact/resources/primereact.min.css";
import "primeicons/primeicons.css";
import {
  BrowserRouter as Router,
  Route,
  Routes,
} from "react-router-dom";
import AddUpdateContact from "./components/AddUpdateContact";
import About from "./components/About";
import MainComponent from "./components/MainComponent";

function App() {

  return (
    <div>
      <Router>
        <div>
          <Layout>
            <Routes>
              <Route path="/" element={<MainComponent />} />
              <Route path="/home" element={<Home />} />
              <Route path="/AddUpdateContact" element={<AddUpdateContact />} />
              <Route
                path="/AddUpdateContact/:id"
                element={<AddUpdateContact />}
              />
              <Route path="/about" element={<About />} />
            </Routes>
          </Layout>
        </div>
      </Router>
    </div>
  );
}

export default App;

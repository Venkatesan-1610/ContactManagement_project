import { useEffect } from "react";
import { useNavigate } from "react-router-dom";

const MainComponent = () => {
  const pathname = window.location.pathname;
  const navigate = useNavigate();
  useEffect(() => {
    if (pathname === "/") {
      navigate("/home");
    }
  }, [pathname, navigate]);
  return;
};
export default MainComponent;

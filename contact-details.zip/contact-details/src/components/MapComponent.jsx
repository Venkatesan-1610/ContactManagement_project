import React, { useEffect, useRef } from 'react';

const MapComponent = ({ people }) => {
  const mapRef = useRef(null);
  const markersRef = useRef([]);

  useEffect(() => {
    const loadGoogleMapsScript = () => {
      const script = document.createElement('script');
      script.src = `https://maps.googleapis.com/maps/api/js?key=AIzaSyDQGedPbebrDKbLmKB6p3RB8z_ww7-J6bs&libraries=places,geometry`;
      script.async = true;
      script.defer = true;
      script.onload = initializeMap;
      document.head.appendChild(script);
    };

    const initializeMap = () => {
      const map = new window.google.maps.Map(mapRef.current, {
        center: {
          lat: people.length > 0 ? people[0].latitude : 0,
          lng: people.length > 0 ? people[0].longitude : 0,
        },
        zoom: 10,
      });

      markersRef.current = people.map((person) => {
        const position = { lat: person.latitude, lng: person.longitude };
        const marker = new window.google.maps.Marker({
          position,
          map,
          title: `${person.firstName} ${person.lastName}`,
        });

        const infoWindow = new window.google.maps.InfoWindow({
          content: `<div><h4>${person.firstName} ${person.lastName}</h4><p>${person.address}</p></div>`,
        });

        marker.addListener('click', () => {
          infoWindow.open(map, marker);
        });

        return marker;
      });
    };

    if (!window.google) {
      loadGoogleMapsScript();
    } else {
      initializeMap();
    }

    return () => {
      markersRef.current.forEach((marker) => marker.setMap(null));
    };
  }, [people]);

  return <div ref={mapRef} style={{ width: '100%', height: '400px' }}></div>;
};

export default MapComponent;

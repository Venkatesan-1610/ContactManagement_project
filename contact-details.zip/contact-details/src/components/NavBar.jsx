import { Link } from "react-router-dom";
import contactLogo from "../assets/images/contact-icon.jpg";
const NavBar = () => {
  return (
    <div>
      <div className="navbar_wrapper">
        <div className="container">
          <div className="navbar_container">
            <div className="d-flex align-items-center">
            <Link to="/home">
              <img
                src={contactLogo}
                alt="logo"
                width="auto"
                height="30px"
              ></img>
              </Link>
              <div className="d-flex align-items-center title">
              <h5>Contact App</h5>
              </div>
            </div>
            <div className="d-flex align-items-center">
              <ul>
                <li>
                  <Link to="/home">Home</Link>
                </li>
                <li>
                <Link to="/about">About</Link>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NavBar;

import Footer from "./Footer";
import NavBar from "./NavBar";
import "../styles/layout.scss";

const Layout = ({ children }) => {
  return (
    <div>
      <NavBar />
      <div className="content">{children}</div>
      <Footer />
    </div>
  );
};

export default Layout;

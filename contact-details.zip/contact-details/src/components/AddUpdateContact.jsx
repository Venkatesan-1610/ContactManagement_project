import React, { useState, useEffect, useRef } from "react";
import { useForm } from "react-hook-form";
import { InputText } from "primereact/inputtext";
import { Button } from "primereact/button";
import config from "../services/config";
import services from "../services";
import "../styles/form.scss";
import { useNavigate, useParams } from "react-router-dom";
import Autocomplete from "react-google-autocomplete";
import { Toast } from "primereact/toast";
import { useDispatch, useSelector } from "react-redux";
import { AddRecentlyAdded } from "../slices/contact";
import Loader from "./Loader";

const AddUpdateContact = () => {
  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
    trigger,
    reset,
  } = useForm({
    mode: "onChange",
    reValidateMode: "onChange",
  });

  const { id } = useParams();
  const toast = useRef(null);
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const contacts = useSelector((state) => state.contacts.contacts);
  const [rowData, setRowData] = useState({});
  const [loading, setLoading] = useState(false);
  const serviceApicall = services.serviceApiCall;
  const extractAddressComponent = (components, type) => {
    const component = components.find((c) => c.types.includes(type));
    return component ? component.long_name : "";
  };

  useEffect(() => {
    if (id) {
      const data = contacts?.find((i) => i?.id === Number(id));
      setRowData(data);
      if (data) {
        setValue("firstName", data.firstName);
        setValue("lastName", data.lastName);
        setValue("email", data.email);
        setValue("address.address", data.address);
        setValue("postalCode", data.postalCode);
        setValue("phoneNumber", data.phoneNumber);
      }
    }
  }, [id, contacts, setValue]);

  const showToast = (severity, detail) => {
    toast.current.show({
      severity,
      detail,
    });
  };

  const submitHandler = async (data) => {
    try {
      const insertContact = config.api.insertContact;
      const updateContact = config.api.updateContact;
      let payload = {
        firstName: data?.firstName,
        lastName: data?.lastName,
        email: data?.email,
        address: data?.address?.address,
        city: data?.address?.city,
        state: data?.address?.state,
        country: data?.address?.country,
        postalCode: data?.postalCode,
        phoneNumber: data?.phoneNumber,
        latitude: data?.address?.latitude,
        longitude: data?.address?.longitude,
      };
      if (rowData?.id) {
        payload = { ...payload, id: rowData?.id };
        setLoading(true);
      }
      const response = await serviceApicall.postCall(
        rowData?.id ? updateContact : insertContact,
        payload
      );
      if (response?.id) {
        showToast(
          "success",
          `Contact ${rowData?.id ? "updated" : "added"} successfully.`
        );
        dispatch(AddRecentlyAdded(response?.id));
        setLoading(true);
        setTimeout(()=>{
          navigate("/home");
        },3000)
      } else if (response?.message) {
        showToast("error", response?.message);
      }
    } catch (error) {
      showToast("error", error);
    }
    finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <h1 className="hometitle">{rowData?.id ? "Update Contact" : "Add Contact"}</h1>
      <div className="form-container">
      {loading && <Loader />}
        <Toast ref={toast} />
        <form onSubmit={handleSubmit(submitHandler)} className="p-fluid">
          <div className="row my-3">
            <div className="col-lg-4">
              <div className="p-field">
                <label htmlFor="firstName">First Name</label>
                <InputText
                  id="firstName"
                  type="text"
                  {...register("firstName", {
                    required: "First name is required",
                    pattern: {
                      value: /^[A-Za-z\s]+$/i,
                      message: "First name should contain alphabets only",
                    },
                  })}
                />
                {errors.firstName && (
                  <small className="error">{errors.firstName.message}</small>
                )}
              </div>
            </div>
            <div className="col-lg-4">
              <div className="p-field">
                <label htmlFor="lastName">Last Name</label>
                <InputText
                  id="lastName"
                  type="text"
                  {...register("lastName", {
                    required: "Last name is required",
                    pattern: {
                      value:/^[A-Za-z\s]+$/i,
                      message: "Last name should contain alphabets only",
                    },
                  })}
                />
                {errors.lastName && (
                  <small className="error">{errors.lastName.message}</small>
                )}
              </div>
            </div>
            <div className="col-lg-4">
              <div className="p-field">
                <label htmlFor="email">Email</label>
                <InputText
                  id="email"
                  type="email"
                  {...register("email", {
                    required: "Email is required",
                    pattern: {
                      value:
                        /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/,
                      message: "Please enter a valid email id",
                    },
                  })}
                />
                {errors.email && (
                  <small className="error">{errors.email.message}</small>
                )}
              </div>
            </div>
          </div>
          <div className="row my-3">
            <div className="col-lg-4">
              <div className="p-field">
                <label htmlFor="address">Address</label>
                <Autocomplete
                  id="address"
                  {...register("address", {
                    validate: (value) => {
                      if (!value?.address) {
                        return "Address is required";
                      }
                      return true;
                    },
                  })}
                  className="p-inputtext p-component"
                  // value={value?.label}
                  apiKey="AIzaSyDQGedPbebrDKbLmKB6p3RB8z_ww7-J6bs"
                  onPlaceSelected={(place) => {
                    const components = place.address_components;
                    const city = extractAddressComponent(
                      components,
                      "locality"
                    );
                    const state = extractAddressComponent(
                      components,
                      "administrative_area_level_1"
                    );
                    const country = extractAddressComponent(
                      components,
                      "country"
                    );
                    const address = place.formatted_address;
                    const location = {
                      address,
                      country,
                      state,
                      city,
                      latitude: place?.geometry?.location?.lat(),
                      longitude: place?.geometry?.location?.lng(),
                    };
                    setValue("address", location);
                    trigger("address");
                  }}
                  placeholder=""
                />
                {errors.address && errors.address.message && (
                  <small className="error">{errors.address.message}</small>
                )}
              </div>
            </div>
            <div className="col-lg-4">
              <div className="p-field">
                <label htmlFor="postalCode">Postal Code</label>
                <InputText
                  id="postalCode"
                  type="text"
                  {...register("postalCode", {
                    required: "Postal code is required",
                    pattern: {
                      value: /^\d{5,6}$/,
                      message: "Please enter a valid postal code",
                    },
                  })}
                />
                {errors.postalCode && (
                  <small className="error">{errors.postalCode.message}</small>
                )}
              </div>
            </div>
            <div className="col-lg-4">
              <div className="p-field">
                <label htmlFor="phoneNumber">Phone Number</label>
                <InputText
                  id="phoneNumber"
                  type="text"
                  {...register("phoneNumber", {
                    required: "Phone number is required",
                    pattern: {
                      value: /^\d{3,16}$/,
                      message: "Please enter a valid phone number",
                    },
                  })}
                />
                {errors.phoneNumber && (
                  <small className="error">{errors.phoneNumber.message}</small>
                )}
              </div>
            </div>
          </div>
          <div className="d-flex justify-content-end">
            <Button
              type="clear"
              className="secondary-button"
              label="Clear"
              onClick={() => {
                reset();
              }}
            />
            <Button
              type="submit"
              className="primary-button"
              label={rowData?.id ? "Update" : "Submit"}
            />
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddUpdateContact;

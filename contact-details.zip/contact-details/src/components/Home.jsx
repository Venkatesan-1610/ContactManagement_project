import React, { useEffect, useState } from "react";
import config from "../services/config";
import services from "../services";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import "../styles/home.scss";
import { Button } from "primereact/button";
import { useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { setContacts } from "../slices/contact";
import { Dropdown } from "primereact/dropdown";
import MapComponent from "./MapComponent";
import Loader from "./Loader";

const Home = () => {
  const contacts = useSelector((state) => state.contacts.contacts);
  const recentlyAdded = useSelector((state) => state.contacts.recentlyAdded);
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const serviceApicall = services.serviceApiCall;
  const [viewMode, setViewMode] = useState("grid");
  const viewOptions = [
    { label: "Grid", value: "grid" },
    { label: "Map", value: "map" },
  ];
  const dispatch = useDispatch();
  useEffect(() => {
    const fetchContacts = async () => {
      try {
        const getContactDetails = config.api.EmployeeDetails;
        const response = await serviceApicall.getAll(getContactDetails);
        if (response?.length > 0) {
          dispatch(setContacts(response));
        }
      } catch (error) {
        console.error("Error fetching contact details:", error);
      }
      finally {
        setLoading(false);
      }
    };

    fetchContacts();
  }, [serviceApicall, dispatch]);

  const fields = [
    { field: "firstName", header: "First Name", width: "15%" },
    { field: "lastName", header: "Last Name", width: "15%" },
    { field: "email", header: "Email", width: "40%" },
    { field: "phoneNumber", header: "Phone Number", width: "" },
    { field: "address", header: "Address", width: "30%" },
    { field: "city", header: "City", width: "" },
    { field: "state", header: "State", width: "" },
    { field: "country", header: "Country", width: "" },
    { field: "postalCode", header: "Postal Code", width: "" },
  ];

  const editContact = (rowData) => {
    navigate(`/AddUpdateContact/${rowData.id}`);
  };

  const deleteContact = async (id) => {
    try {
      const deleteUrl = config.api.DeleteEmployee(id);
      await serviceApicall.removeCall(deleteUrl);
      const getContactDetails = config.api.EmployeeDetails;
      const response = await serviceApicall.getAll(getContactDetails);
      dispatch(setContacts(response));
    } catch (error) {
      console.error("Error deleting contact:", error);
    }
  };

  const actionBodyTemplate = (rowData) => {
    return (
      <React.Fragment>
       <div style={{ display: "flex", gap: "10px" }}>
        <Button
          icon="pi pi-pencil"
          rounded
          severity="secondary"
          onClick={() => editContact(rowData)}
        />
        <Button
          icon="pi pi-trash"
          rounded
          severity="danger"
          onClick={() => deleteContact(rowData.id)}
        />
      </div>
      </React.Fragment>
    );
  };

  const rowClassName = (rowData) => {
    return {
      highlight: rowData.id === recentlyAdded,
    };
  };

  return (
    <div className="home-container m-5 p-5">
      {loading && <Loader />}
      <h1 className="hometitle">{viewMode === "grid" ? "Contact Manager Dashboard" : "Map View"}</h1>
      <div className="d-flex justify-content-between">
        <Dropdown
          value={viewMode}
          onChange={(e) => setViewMode(e.value)}
          options={viewOptions}
          optionLabel="label"
        />
        <Button
          icon="pi pi-plus"
          label="Add Contact"
          className="secondary-button"
          onClick={() => navigate("/AddUpdateContact")}
        />
      </div>
      <div className="card contact_datatable">
        {viewMode === "map" && <MapComponent people={contacts}/>}
        {viewMode === "grid" && (
          <DataTable
            value={contacts}
            sortOrder={-1}
            tableStyle={{ minWidth: "50rem" }}
            paginator
            rows={10}
            dataKey="id"
            rowClassName={rowClassName}
          >
            {fields?.map((col) => (
              <Column
                key={col.field}
                field={col.field}
                header={col.header}
                sortable
                style={{ width: col.width }}
              />
            ))}
            <Column body={actionBodyTemplate} header="Actions"></Column>
          </DataTable>
        )}
      </div>
    </div>
  );
};

export default Home;

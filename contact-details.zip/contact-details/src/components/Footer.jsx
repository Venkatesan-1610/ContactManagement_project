const Footer = () => {
  return (
    <div className="footer_wrapper footer bg-neutral pt-4">
      <div className="container text-center py-4">
        <div className="row">
          <div className="col-sx-12 col-sm-12 col-md-6 col-lg-4 text-start">
            <h6 className="my-3">About Us</h6>
            <p>
              Our application helps you manage your contacts efficiently. Add, update, and view contact details, and see their locations on a map. Simplify your contact management with our user-friendly interface.
            </p>
          </div>

          <div className="col-sx-12 col-sm-12 col-md-6 col-lg-4 text-start">
            <h6 className="my-3">Address</h6>
            <ul>
              <li>1141, </li>
              <li>Chennai,</li>
              <li>Tamil Nadu 600044</li>
            </ul>
          </div>

          <div className="col-sx-12 col-sm-12 col-md-6 col-lg-4 text-start">
            <h6 className="my-3">Contact</h6>
            <ul>
              <li>Email: support@contactmanager.com</li>
              <li>Phone: +91 9556647522</li>
              <li>(9am to 7pm India Standard Time)</li>
            </ul>
          </div>
        </div>
      </div>
      <div className="copyright-wr py-3">
        <div className="container text-center">
          <div className="row">
            <div className="col-sx-12 col-sm-12 col-md-6 col-lg-6 text-start">
              <span className="">&copy;</span>
              <span>
                {new Date().getFullYear()} Contact Manager. All rights reserved.
              </span>
            </div>
            <div className="col-sx-12 col-sm-12 col-md-6 col-lg-6 text-end">
              <span>Privacy Policy</span> | <span>Terms of Service</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Footer;

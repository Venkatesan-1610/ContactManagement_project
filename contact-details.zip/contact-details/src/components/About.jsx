import React from "react";
import "../styles/about.scss";

function About() {
  return (
    <div className="about-container m-5 p-5">
      <h1>About Our Contact Management Application</h1>
      <p>
        Welcome to our Contact Management Application! This app is designed to
        help you manage your contacts efficiently and effectively. Whether
        you're looking to keep track of personal contacts, business contacts, or
        both, our app provides all the necessary tools to make your life easier.
      </p>
      <h2>Features</h2>
      <ul>
        <li>Add, update, and delete contacts easily.</li>
        <li>View contacts in both grid and map views for better organization and visualization.</li>
        <li>Search for contacts quickly using our advanced search functionality.</li>
        <li>Organize your contacts with custom categories and tags.</li>
        <li>Securely store your contact information with state-of-the-art encryption.</li>
      </ul>
      <h2>About Our Team</h2>
      <p>
        Our team is dedicated to providing the best possible user experience. We
        continuously work on improving the app and adding new features based on
        user feedback. If you have any suggestions or feedback, please do not
        hesitate to reach out to us.
      </p>
      <p>
        Contact us at:{" "}
        <a href="mailto:support@contactapp.com">support@contactapp.com</a>
      </p>
    </div>
  );
}

export default About;

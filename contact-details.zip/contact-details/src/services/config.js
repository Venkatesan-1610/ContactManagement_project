const config = {
    devApi: {
        spcHostUrl: "https://localhost:7271/api/"
    },

    api: {
        EmployeeDetails: "EmployeeDetails/GetEmployeeDetails",
        insertContact: "EmployeeDetails/AddEmployee",
        updateContact: "EmployeeDetails/UpdateEmployee",
        DeleteEmployee: (id) => `EmployeeDetails/DeleteEmployee/${id}`


    }
}
export default config;
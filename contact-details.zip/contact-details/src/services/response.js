import axios from 'axios';

export function handleResponse(response) {
    if (response.results) {
        return response.results;
    }
    if (response.data) {
        return response.data ;
    }
    return response;
}

export function handleResponseWithStatus(response) {
    if (response.results) {
        return response.results;
    }
    if (response.data) {
        return response.data ;
    }
    return response;
}

export function handleError(error) {
    if (axios.isCancel(error)) {
        return 'request cancelled';
    }
    if (error.data) {
        return error.data ;
    }
    if (error.response) {
        let resData = error.response
        if (resData.data) {
            return resData.data
        } else {
            return error.response
        }
    }
    return error;
}

export function handleErrorWithStatus(error) {
    if (axios.isCancel(error)) {
        return 'request cancelled';
    }
    return error;
}
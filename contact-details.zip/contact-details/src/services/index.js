import apiCore from "./apiCore";

const services =  {
    serviceApiCall: apiCore,
}
export default services;
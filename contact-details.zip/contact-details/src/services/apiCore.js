import { apiProvider } from "./provider";

const apiCore = {
    getAll(url, cancelToken) {
        return apiProvider.getAll(url, cancelToken);
    },
    getDataById(url, id) {
        return apiProvider.getDataById(url, id);
    },
    postCall(url, payload) {
        return apiProvider.postCall(url, payload);
    },
    postCallById(url, id, payload) {
        return apiProvider.postCallById(url, id, payload);
    },
    removeCall(url, payload) {
        return apiProvider.removeCall(url, payload);
    },
    updateCall(url, payload) {
        return apiProvider.updateCall(url, payload);
    },
    updateCallById(url, id, payload) {
        return apiProvider.updateCallById(url, id, payload);
    },
};

export default apiCore;

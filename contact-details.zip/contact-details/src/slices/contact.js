import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  contacts: [],
  recentlyAdded: "",
};

const contactSlice = createSlice({
  name: "contacts",
  initialState,
  reducers: {
    addContact: (state, action) => {
      state.contacts += action.payload;
    },
    setContacts: (state, action) => {
      state.contacts = action.payload || [];
    },
    updateContact: (state, action) => {
      const { id } = action.payload;
      const existingContact = state.contacts.find(
        (contact) => contact.id === id
      );
      if (existingContact) {
        Object.assign(existingContact, action.payload);
      }
    },
    AddRecentlyAdded: (state, action) => {
      state.recentlyAdded = action.payload;
    },
  },
});

export const { addContact, setContacts, updateContact, AddRecentlyAdded } = contactSlice.actions;
export default contactSlice.reducer;

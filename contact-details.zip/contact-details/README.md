Contact App
This project is a simple Contact Application built with React using Create React App.

Description
The Contact App allows users to manage their contacts efficiently and effectively. Users can add, update, and delete contacts easily, search for contacts quickly using advanced search functionality, and organize contacts with custom categories and tags. The application provides a user-friendly interface for securely storing contact information.

Getting Started
To get started with the Contact App, follow these steps:

1) Clone this repository to your local machine.
2) Navigate to the project directory.
3) Run npm install to install the dependencies.
4) Run npm start to start the development server.
5) Open http://localhost:3000 in your web browser to view the app.
6) Added API connection in services folder in config file https://localhost:7271/api/. 
7) Now you can add or update contact details. 
﻿using EmployeeDetails.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace EmployeeDetails.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeDetailsController : ControllerBase
    {
        private readonly string _connectionString;

        public EmployeeDetailsController(IConnectionStringProvider connectionStringProvider)
        {
            _connectionString = connectionStringProvider.GetConnectionString();
        }

        // Get Employee details 
        [HttpGet]
        [Route("GetEmployeeDetails")]
        public IActionResult GetEmployees()
        {
            try
            {
                List<EmployeeDetailsResponse> employeeDetailsResponses = new List<EmployeeDetailsResponse>();

                using (SqlConnection connection = new SqlConnection(_connectionString))
                {
                    SqlCommand command = new SqlCommand("SELECT  * FROM Employee_Details ORDER BY EmployeeID DESC", connection);

                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        EmployeeDetailsResponse employee = new EmployeeDetailsResponse
                        {
                            firstName = reader["First_Name"].ToString(),
                            lastName = reader["Last_Name"].ToString(),
                            email = reader["Email_Id"].ToString(),
                            address = reader["Address"].ToString(),
                            city = reader["City"].ToString(),
                            state = reader["State"].ToString(),
                            country = reader["Country"].ToString(),
                            postalCode = Convert.ToInt32(reader["Postal_Code"]),
                            phoneNumber = reader["Phone_Number"].ToString(),
                            id = Convert.ToInt32(reader["EmployeeID"]),
                            longitude = Convert.ToSingle(reader["Longitude"]),
                            latitude = Convert.ToSingle(reader["Latitude"])
                        };
                        employeeDetailsResponses.Add(employee);
                    }
                    reader.Close();
                }

                return Ok(employeeDetailsResponses);
            }
            catch (SqlException ex)
            {
                return StatusCode(500, $"SQL error occurred: {ex.Message}");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An unexpected error occurred: {ex.Message}");
            }
        }

        // Add employee
        [HttpPost]
        [Route("AddEmployee")]
        public IActionResult AddEmployee(EmployeeDetailsRequest employeeRequest)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(_connectionString))
                {
                    SqlCommand command = new SqlCommand("Insert_Employee_Info", connection);
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.AddWithValue("@FirstName", employeeRequest.firstName);
                    command.Parameters.AddWithValue("@LastName", employeeRequest.lastName);
                    command.Parameters.AddWithValue("@Email", employeeRequest.email);
                    command.Parameters.AddWithValue("@Address", employeeRequest.address);
                    command.Parameters.AddWithValue("@City", employeeRequest.city);
                    command.Parameters.AddWithValue("@State", employeeRequest.state);
                    command.Parameters.AddWithValue("@Country", employeeRequest.country);
                    command.Parameters.AddWithValue("@PostalCode", employeeRequest.postalCode);
                    command.Parameters.AddWithValue("@PhoneNumber", employeeRequest.phoneNumber);
                    command.Parameters.AddWithValue("@Longitude", employeeRequest.longitude);
                    command.Parameters.AddWithValue("@Latitude", employeeRequest.latitude);

                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    EmployeeDetailsResponse newEmployee = null;
                    if (reader.Read())
                    {
                        newEmployee = new EmployeeDetailsResponse
                        {
                            firstName = reader["First_Name"].ToString(),
                            lastName = reader["Last_Name"].ToString(),
                            email = reader["Email_Id"].ToString(),
                            address = reader["Address"].ToString(),
                            city = reader["City"].ToString(),
                            state = reader["State"].ToString(),
                            country = reader["Country"].ToString(),
                            postalCode = Convert.ToInt32(reader["Postal_Code"]),
                            phoneNumber = reader["Phone_Number"].ToString(),
                            id = Convert.ToInt32(reader["EmployeeID"]),
                            longitude = Convert.ToSingle(reader["Longitude"]),
                            latitude = Convert.ToSingle(reader["Latitude"])
                        };
                    }
                    reader.Close();

                    if (newEmployee != null)
                    {
                        return Ok(newEmployee);
                    }
                    else
                    {
                        return BadRequest("Failed to add employee.");
                    }
                }
            }
            catch (SqlException ex)
            {
                if (ex.Number == 50000)
                {
                    return Conflict(new { Message = ex.Message });
                }
                return StatusCode(500, $"SQL error occurred: {ex.Message}");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An unexpected error occurred: {ex.Message}");
            }
        }

        // Update employee
        [HttpPost]
        [Route("UpdateEmployee")]
        public IActionResult UpdateEmployee(EmployeeDetailsRequest employeeRequest)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(_connectionString))
                {
                    SqlCommand command = new SqlCommand("Update_Employee_Info", connection);
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.AddWithValue("@EmployeeID", employeeRequest.id);
                    command.Parameters.AddWithValue("@FirstName", employeeRequest.firstName);
                    command.Parameters.AddWithValue("@LastName", employeeRequest.lastName);
                    command.Parameters.AddWithValue("@Email", employeeRequest.email);
                    command.Parameters.AddWithValue("@Address", employeeRequest.address);
                    command.Parameters.AddWithValue("@City", employeeRequest.city);
                    command.Parameters.AddWithValue("@State", employeeRequest.state);
                    command.Parameters.AddWithValue("@Country", employeeRequest.country);
                    command.Parameters.AddWithValue("@PostalCode", employeeRequest.postalCode);
                    command.Parameters.AddWithValue("@PhoneNumber", employeeRequest.phoneNumber);
                    command.Parameters.AddWithValue("@Longitude", employeeRequest.longitude);
                    command.Parameters.AddWithValue("@Latitude", employeeRequest.latitude);

                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    EmployeeDetailsResponse updatedEmployee = null;
                    if (reader.Read())
                    {
                        updatedEmployee = new EmployeeDetailsResponse
                        {
                            firstName = reader["First_Name"].ToString(),
                            lastName = reader["Last_Name"].ToString(),
                            email = reader["Email_Id"].ToString(),
                            address = reader["Address"].ToString(),
                            city = reader["City"].ToString(),
                            state = reader["State"].ToString(),
                            country = reader["Country"].ToString(),
                            postalCode = Convert.ToInt32(reader["Postal_Code"]),
                            phoneNumber = reader["Phone_Number"].ToString(),
                            id = Convert.ToInt32(reader["EmployeeID"]),
                            longitude = Convert.ToSingle(reader["Longitude"]),
                            latitude = Convert.ToSingle(reader["Latitude"])
                        };
                    }
                    reader.Close();

                    if (updatedEmployee != null)
                    {
                        return Ok(updatedEmployee);
                    }
                    else
                    {
                        return BadRequest("Failed to update employee.");
                    }
                }
            }
            catch (SqlException ex)
            {
                return StatusCode(500, $"SQL error occurred: {ex.Message}");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An unexpected error occurred: {ex.Message}");
            }
        }

        // Delete employee
        [HttpDelete]
        [Route("DeleteEmployee/{id}")]
        public IActionResult DeleteEmployee(int id)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(_connectionString))
                {
                    SqlCommand command = new SqlCommand("DELETE FROM Employee_Details WHERE EmployeeID = @EmployeeID", connection);
                    command.Parameters.AddWithValue("@EmployeeID", id);

                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        return Ok(new { message = "Employee deleted successfully." });
                    }
                    else
                    {
                        return NotFound(new { message = "Employee not found." });
                    }
                }
            }
            catch (SqlException ex)
            {
                return StatusCode(500, $"SQL error occurred: {ex.Message}");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An unexpected error occurred: {ex.Message}");
            }
        }
    }
}

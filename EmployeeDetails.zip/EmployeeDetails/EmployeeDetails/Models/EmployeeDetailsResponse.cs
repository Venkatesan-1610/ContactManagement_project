﻿namespace EmployeeDetails.Models
{
    public class EmployeeDetailsResponse
    {
        public string? firstName { get; set; }
        public string? lastName { get; set; }
        public string? email { get; set; }
        public string? address { get; set; }
        public string? city { get; set; }
        public string? state { get; set; }
        public string? country { get; set; }
        public Int32 postalCode { get; set; }
        public string? phoneNumber { get; set; }
        public Int32 id { get; set; }
        public float longitude { get; set; }
        public float latitude { get; set; }
    }
}

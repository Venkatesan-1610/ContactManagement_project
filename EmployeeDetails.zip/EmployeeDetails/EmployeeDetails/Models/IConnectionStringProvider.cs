﻿namespace EmployeeDetails.Models
{
    public interface IConnectionStringProvider
    {
        string GetConnectionString();
    }
}
